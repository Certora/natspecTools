from .natspec_parser import *

__doc__ = natspec_parser.__doc__
if hasattr(natspec_parser, "__all__"):
    __all__ = natspec_parser.__all__